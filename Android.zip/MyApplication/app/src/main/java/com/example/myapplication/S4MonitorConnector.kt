package com.example.myapplication

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbManager
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class S4MonitorConnector(
    private val context: Context,
    private val usbManager: UsbManager
) {

    class ConnectionResult(
        val connection: UsbDeviceConnection,
        val readEndpoint: UsbEndpoint,
        val writeEndpoint: UsbEndpoint
    )

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    suspend fun connect(): ConnectionResult = suspendCoroutine { continuation ->

        val device =
            usbManager.deviceList.values.find { it.vendorId == 1240 && it.productId == 10 }
        if (device == null) {
            error("Device not found")
        }

        if (!usbManager.hasPermission(device)) {
            context.registerReceiver(
                PermissionGrantedBroadcastReceiver(
                    device,
                    onConnected = { continuation.resume(it) }
                ),
                IntentFilter("com.example.myapplication.USB_PERMISSION"),
            )

            usbManager.requestPermission(
                device,
                PendingIntent.getBroadcast(
                    context,
                    42,
                    Intent("com.example.myapplication.USB_PERMISSION"),
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
        } else {
            openConnection(
                device = device,
                onConnected = { continuation.resume(it) }
            )
        }
    }

    private inner class PermissionGrantedBroadcastReceiver(
        private val device: UsbDevice,
        private val onConnected: (ConnectionResult) -> Unit
    ) : BroadcastReceiver() {

        override fun onReceive(context: Context?, intent: Intent?) {
            openConnection(
                device = device,
                onConnected = onConnected
            )
        }
    }

    private fun openConnection(
        device: UsbDevice,
        onConnected: (ConnectionResult) -> Unit
    ) {
        val connection = usbManager.openDevice(device)
            ?: error("Could not open device")

        val cdcInterface = (0 until device.interfaceCount)
            .map { device.getInterface(it) }
            .find { it.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA }
            ?: error("CDC interface not found")

        val readEndpoint = (0 until cdcInterface.endpointCount)
            .map { cdcInterface.getEndpoint(it) }
            .find { it.direction == UsbConstants.USB_DIR_IN }
            ?: error("Read endpoint not found")

        val writeEndpoint = (0 until cdcInterface.endpointCount)
            .map { cdcInterface.getEndpoint(it) }
            .find { it.direction == UsbConstants.USB_DIR_OUT }
            ?: error("Write endpoint not found")

        if (!connection.claimInterface(cdcInterface, true)) {
            error("Could not claim interface")
        }

        // Enable Data Terminal Ready (DTR) to indicate that the device is ready to communicate.
        connection.controlTransfer(0x21, 0x22, 0x1, 0, null, 0, 0)

        onConnected(
            ConnectionResult(
                connection,
                readEndpoint,
                writeEndpoint
            )
        )
    }
}
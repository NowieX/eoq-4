package com.example.myapplication

/**
 * Collects bytes and processes them into separate lines.
 */
internal class LineGatherer(bufferSize: Int = 128) {

    private val lineBuffer = ByteArray(bufferSize)
    private var lineOffset = 0

    /**
     * Process given [byte], appending it to the internal buffer.
     *
     * If a complete line was formed (ending with Carriage Return + Line Feed),
     * the line is returned without the CR+LF and the buffer is cleared.
     *
     * Otherwise, null is returned.
     */
    fun process(byte: Byte): String? {
        lineBuffer[lineOffset] = byte

        val lineIsComplete =
            byte == lineFeed && lineOffset > 0 && lineBuffer[lineOffset - 1] == carriageReturn
        if (lineIsComplete) {
            val result = String(lineBuffer, 0, lineOffset - 1, Charsets.US_ASCII)
            lineOffset = 0
            return result
        }

        lineOffset++
        return null
    }

    companion object {

        const val carriageReturn: Byte = 13
        const val lineFeed: Byte = 10
    }
}

package com.example.myapplication

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.time.Duration.Companion.milliseconds

class S4MonitorReader(
    private val connection: UsbDeviceConnection,
    private val readEndpoint: UsbEndpoint,
    private val writeEndpoint: UsbEndpoint,
) {

    suspend fun start() = coroutineScope {
        launch {
            startReading()
        }

        launch {
            write("USB")
            delay(25.milliseconds)
            while (isActive) {
                // Request stroke rate
                write("IRS1A9")
                delay(25.milliseconds)

                // Request distance
                write("IRD057")
                delay(25.milliseconds)
            }
        }
    }

    private fun write(message: String) {
        val bytes = message.toByteArray(Charsets.US_ASCII) + 0x0d + 0x0a
        Log.v("Usb", "Write: \"$message\" (${bytes.contentToString()})")
        connection.bulkTransfer(writeEndpoint, bytes, bytes.size, 500)
    }

    private suspend fun startReading() = withContext(Dispatchers.IO) {
        val lineGatherer = LineGatherer()
        val readBuffer = ByteArray(1024)
        while (isActive) {
            val readCount =
                connection.bulkTransfer(readEndpoint, readBuffer, readBuffer.size, 500)
            for (i in 0 until readCount) {
                val line = lineGatherer.process(readBuffer[i])
                if (line != null) {
                    Log.v("Usb", "Read \"$line\"")
                    process(line)
                }
            }
        }
    }

    private fun process(line: String) {
        when {
            line == "PING" -> Log.v("Usb", "Ping")
            line == "SS" -> Log.v("Usb", "Stroke start")
            line == "SE" -> Log.v("Usb", "Stroke end")

            line.startsWith("P") -> {
                val pulseCount = line.drop(1).toInt(16) // Pulses in the last 25 ms
                Log.v("Usb", "Pulse count: $pulseCount")
            }

            line.startsWith("IDS1A9") -> {
                val y1 = line.drop(6)
                val strokeRate = y1.toInt(16)
                Log.v("Usb", "Stroke rate: $strokeRate")
            }

            line.startsWith("IDD057") -> {
                val y2 = line.drop(6).take(2)
                val y1 = line.drop(8).take(2)
                val distance = ("$y2$y1").toInt(16)
                Log.v("Usb", "Distance: $distance")
            }
        }
    }
}